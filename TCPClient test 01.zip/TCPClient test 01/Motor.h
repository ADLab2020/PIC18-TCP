
#ifndef MOTOR_H
#define MOTOR_H

// Definitions
#define FORWARD     1
#define BACKWARD    0

// Functions
void initMotors(void);

// Attention: speed has to be in the range [-1023,1023]
void setSpeedMotor1(short speed);
//void setSpeedMotor2(short speed);

void stopMotors(void);


#endif // MOTOR_H