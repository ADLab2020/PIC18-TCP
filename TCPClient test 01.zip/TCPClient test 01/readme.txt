PIC18F4550 uses the project in the following path:

H:\Lab\Robot\Project_Robot

and its main-function is "robotController.c" which has already been copied in this folder.