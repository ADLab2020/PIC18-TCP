
#ifndef __COMPILER_H
#define __COMPILER_H


// PIC18 processor with Microchip C18 compiler
#define COMPILER_MPLAB_C18
#include <p18f4685.h>




#include <stdio.h>
#include <stdlib.h>
#include <string.h>



// Base RAM and ROM pointer types for given architecture

#if defined(COMPILER_MPLAB_C18)
	#define PTR_BASE		unsigned short
	#define ROM_PTR_BASE	unsigned short long
#endif





// Definitions that apply to all 8-bit products
// (PIC18)

#define	__attribute__(a)
#define FAR                         far

// Microchip C18 specific defines
#if defined(COMPILER_MPLAB_C18)
	#define ROM                 	rom
#endif
	


#endif
