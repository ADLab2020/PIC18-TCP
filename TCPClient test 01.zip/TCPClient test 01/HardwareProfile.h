
#ifndef HARDWARE_PROFILE_H
#define HARDWARE_PROFILE_H

#include "Microchip/Include/Compiler.h"

// Define a macro describing this hardware set up (used in other files)
#define PIC18_EXPLORER

/***************************************************************************************/

// Set configuration fuses (but only in MainDemo.c where THIS_IS_STACK_APPLICATION is defined)
#if defined(THIS_IS_STACK_APPLICATION)


		// CPU Clock: 48MHz
//	#pragma config   PLLDIV    =   5           // Divide by 5 (20 MHz oscillator input)
	#pragma config   OSC      =   HSPLL    // HS oscillator, PLL enabled, HS used by USB
//	#pragma config   CPUDIV    =   OSC1_PLL2   // System Clock Postscaler Selection bits
	
	// USB: enabled
//	#pragma config   USBDIV    =   2           // USB Clock: 48 Mhz
//	#pragma config   VREGEN    =   ON          // USB Voltage Regulator: enabled
	
	// Brown-out Reset: disabled
//	#pragma config   BOR       =   OFF         // Brown-out Reset enabled in hardware only (SBOREN is disabled)
	#pragma config   BORV      =   3           // Brown-out Reset Voltage bits
	
	// Watchdog Timer: disabled
	#pragma config   WDT       =   OFF         // Watchdog Timer Enable bit
	#pragma config   WDTPS     =   32768       // Watchdog Timer Postscale Select bits
	
	// Miscellaneous
	#pragma config   IESO      =   OFF         // Oscillator Switchover mode: disabled
	#pragma config   FCMEN     =   OFF         // Fail-Safe Clock Monitor: disabled
	#pragma config   PWRT      =   OFF         // Power-up Timer: disabled
	#pragma config   MCLRE     =   ON          // MCLR pin: enabled; RE3 input pin: disabled
	#pragma config   LPT1OSC   =   OFF         // Low-Power Timer1 Oscillator: disabled
//	#pragma config   PBADEN    =   OFF         // PORB digital IO on powerup
//	#pragma config   CCP2MX    =   ON          // CCP2 is multiplexed to RC1 (not RB3)
	#pragma config   XINST     =   OFF         // Extended Instruction Set: disabled
	#pragma config   LVP       =   OFF         // Low-voltage programming: disabled
	#pragma config   STVREN    =   ON          // Stack Full/Underflow Reset: enabled
	
	// Code Protection: disabled
	#pragma config   CPB       =   OFF         // Boot Block Code Protection bit
	#pragma config   CPD       =   OFF         // Data EEPROM Code Protection bit
	#pragma config   CP0       =   OFF         // Code Protection bit Block 0
	#pragma config   CP1       =   OFF         // Code Protection bit Block 1
	#pragma config   CP2       =   OFF         // Code Protection bit Block 2
	#pragma config   CP3       =   OFF         // Code Protection bit Block 3
	
	// Write Protection: disabled
	#pragma config   WRTC      =   OFF         // Configuration Register Write Protection bit
	#pragma config   WRTB      =   OFF         // Boot Block Write Protection bit
	#pragma config   WRTD      =   OFF         // Data EEPROM Write Protection bit
	#pragma config   WRT0      =   OFF         // Write Protection bit Block 0
	#pragma config   WRT1      =   OFF         // Write Protection bit Block 1
	#pragma config   WRT2      =   OFF         // Write Protection bit Block 2
	#pragma config   WRT3      =   OFF         // Write Protection bit Block 3
	
	// Table Read Protection: disabled
	#pragma config   EBTRB     =   OFF         // Boot Block Table Read Protection bit
	#pragma config   EBTR0     =   OFF         // Table Read Protection bit Block 0
	#pragma config   EBTR1     =   OFF         // Table Read Protection bit Block 1
	#pragma config   EBTR2     =   OFF         // Table Read Protection bit Block 2
	#pragma config   EBTR3     =   OFF         // Table Read Protection bit Block 3

#endif


/*****************************************************************************/



// Clock frequency values
// These directly influence timed events using the Tick module.  They also are used for UART and SPI baud rate generation.

#define GetSystemClock()	(40000000ul)			// Hz
#define GetInstructionClock()	(GetSystemClock()/4)	// Should be GetSystemClock()/4 for PIC18
#define GetPeripheralClock()	(GetSystemClock()/4)	// Should be GetSystemClock()/4 for PIC18





/*********************************************************************************/
/*                        Hardware I/O pin mappings                              */
/*********************************************************************************/

// Constants
//#define TRUE    1
//#define FALSE   0
#define HIGH    1
#define LOW     0
#define PRESSED 0
#define INPUT   1
#define OUTPUT  0


// LEDs
#define LED0_TRIS			(TRISDbits.TRISD0)	// Ref D1
#define LED0_IO				(LATDbits.LATD0)
#define LED1_TRIS			(TRISDbits.TRISD1)	// Ref D2
#define LED1_IO				(LATDbits.LATD1)
#define LED2_TRIS			(TRISDbits.TRISD2)	// Ref D3
#define LED2_IO				(LATDbits.LATD2)
#define LED3_TRIS			(TRISDbits.TRISD3)	// Ref D4
#define LED3_IO				(LATDbits.LATD3)
#define LED4_TRIS			(TRISDbits.TRISD4)	// Ref D5
#define LED4_IO				(LATDbits.LATD4)
#define LED5_TRIS			(TRISDbits.TRISD5)	// Ref D6
#define LED5_IO				(LATDbits.LATD5)
#define LED6_TRIS			(TRISDbits.TRISD6)	// Ref D7
#define LED6_IO				(LATDbits.LATD6)
#define LED7_TRIS			(TRISDbits.TRISD7)	// Ref D8
#define LED7_IO				(LATDbits.LATD7)
#define LED_GET()			(LATD)
#define LED_PUT(a)			(LATD = (a))

// Momentary push buttons
#define BUTTON1_TRIS		(TRISBbits.TRISB0)
#define	BUTTON1_IO			(PORTBbits.RB0)



// Motor driver
#define MOTOR1_0            PORTCbits.RC2
#define MOTOR1_0_DIR        TRISCbits.TRISC2
#define MOTOR1_1            PORTAbits.RA4
#define MOTOR1_1_DIR        TRISAbits.TRISA4
  


// ENC28J60 I/O pins
#define ENC_RST_TRIS		(TRISBbits.TRISB5)
#define ENC_RST_IO			(LATBbits.LATB5)
#define ENC_CS_TRIS			(TRISBbits.TRISB3)
#define ENC_CS_IO			(LATBbits.LATB3)
#define ENC_SCK_TRIS		(TRISCbits.TRISC3)
#define ENC_SDI_TRIS		(TRISCbits.TRISC4)
#define ENC_SDO_TRIS		(TRISCbits.TRISC5)
#define ENC_SPI_IF			(PIR1bits.SSPIF)
#define ENC_SSPBUF			(SSPBUF)
#define ENC_SPISTAT			(SSPSTAT)
#define ENC_SPISTATbits		(SSPSTATbits)
#define ENC_SPICON1			(SSPCON1)
#define ENC_SPICON1bits		(SSPCON1bits)
#define ENC_SPICON2			(SSPCON2


/*********************************************************************************/
/*                        Hardware I/O pin mappings -- END                            */
/*********************************************************************************/




// UART mapping functions for consistent API names across 8-bit and 16 or 
// 32 bit compilers.  For simplicity, everything will use "UART" instead 
// of USART/EUSART/etc.



/*
#define BusyUART()			BusyUSART()
#define CloseUART()			CloseUSART()
#define ConfigIntUART(a)	ConfigIntUSART(a)
#define DataRdyUART()		DataRdyUSART()
#define OpenUART(a,b,c)		OpenUSART(a,b,c)
#define ReadUART()			ReadUSART()
#define WriteUART(a)		WriteUSART(a)
#define getsUART(a,b,c)		getsUSART(b,a)
#define putsUART(a)			putsUSART(a)
#define getcUART()			ReadUSART()
#define putcUART(a)			WriteUSART(a)
#define putrsUART(a)		putrsUSART((far rom char*)a)


*/

#endif // #ifndef HARDWARE_PROFILE_H
