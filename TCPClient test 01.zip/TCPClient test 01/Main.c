/*********************************************************************

 * FileName:        Main.c
 * Dependencies:    TCPIP.h

 ********************************************************************/

#define THIS_IS_STACK_APPLICATION




// Include functions specific to this stack application
#include "Main.h"
#include "Microchip/Include/GenericTypeDefs.h"
#include "Microchip/Include/TCPIP Stack/Delay.h"
#include "Motor.h"
#include <usart.h>


static void InitializeBoard(void);
void initUsart(void);





//
// PIC18 Interrupt Service Routines
// 
// NOTE: Several PICs, including the PIC18F4620 revision A3 have a RETFIE FAST/MOVFF bug
// The interruptlow keyword is used to work around the bug when using C18

	#pragma interruptlow LowISR
	void LowISR(void)
	{
	   
	}
	

	#pragma interruptlow HighISR
	void HighISR(void)
	{
	   
	}


	#pragma code lowVector=0x18
	void LowVector(void){_asm goto LowISR _endasm}
	#pragma code highVector=0x8
	void HighVector(void){_asm goto HighISR _endasm}
	#pragma code // Return to default code section






// Defines the server to be accessed for this application
//static BYTE ServerName[] =	"192.168.0.194";
//static WORD ServerPort = 2000;





//
// Main application entry point.
//

void main(void)
{
	int started=0;
	int counter=0;
	static DWORD t = 0;
	static DWORD dwLastIP = 0;
    int flag=0;
     BYTE vBuffer[20]="123456789abcdefghij";
    
      int index=0;
	// Initialize application specific hardware
	InitializeBoard();
    initMotors();
    initUsart();
	DelayMs(100);
	
while(1)
{
	/*
	setSpeedMotor1(1023);
	LED0_IO=1; DelayMs(1000);
	LED1_IO=1; DelayMs(1000);
	LED2_IO=1; DelayMs(1000);
	LED3_IO=1; DelayMs(1000);
	LED4_IO=1; DelayMs(1000);
	LED5_IO=1; DelayMs(1000);
	LED6_IO=1; DelayMs(1000);
	
	stopMotors();
	LED0_IO=0;
	LED1_IO=0;
	LED2_IO=0;
	LED3_IO=0;
	LED4_IO=0;
	LED5_IO=0;
	LED6_IO=0;
	DelayMs(1000);
	
	setSpeedMotor1(-1023);
	LED0_IO=1; DelayMs(300);
	LED0_IO=0; DelayMs(300);
	LED1_IO=1; DelayMs(300);
	LED1_IO=0; DelayMs(300);
	LED2_IO=1; DelayMs(300);
	LED2_IO=0; DelayMs(300);
	LED3_IO=1; DelayMs(300);
	LED3_IO=0; DelayMs(300);
	LED4_IO=1; DelayMs(300);
	LED4_IO=0; DelayMs(300);
	LED5_IO=1; DelayMs(300);
	LED5_IO=0; DelayMs(300);
	LED6_IO=1; DelayMs(300);
	LED6_IO=0; DelayMs(300);
	*/
	
	
	if(BUTTON1_IO==PRESSED){
	   	
       if(counter%5==0)  { putcUSART(0b00111100);LED0_IO=1;LED1_IO=0;LED2_IO=0;LED3_IO=0;LED4_IO=0;DelayMs(300); }
       if(counter%5==1)  { putcUSART(0b11000011);LED0_IO=0;LED1_IO=1;LED2_IO=0;LED3_IO=0;LED4_IO=0;DelayMs(300); }
       if(counter%5==2)  { putcUSART(0b11110000);LED0_IO=0;LED1_IO=0;LED2_IO=1;LED3_IO=0;LED4_IO=0;DelayMs(300); }
       if(counter%5==3)  { putcUSART(0b00001111);LED0_IO=0;LED1_IO=0;LED2_IO=0;LED3_IO=1;LED4_IO=0;DelayMs(300); }
       if(counter%5==4)  { putcUSART(0b11111111);LED0_IO=0;LED1_IO=0;LED2_IO=0;LED3_IO=0;LED4_IO=1;DelayMs(300); }
       counter=counter+1;
       if(counter==5)  counter=0;
	}
	else {DelayMs(50);}	
	


	
}	






}




	
		
		
		
	
		
		
		
		
	



/****************************************************************************
  Function:
    static void InitializeBoard(void)

  Description:
    This routine initializes the hardware.  It is a generic initialization
    routine for many of the Microchip development boards, using definitions
    in HardwareProfile.h to determine specific initialization.

  Precondition:
    None

  Parameters:
    None - None

  Returns:
    None

  Remarks:
    None
  ***************************************************************************/
static void InitializeBoard(void)
{	
	// LEDs
	LED0_TRIS = 0;
	LED1_TRIS = 0;
	LED2_TRIS = 0;
	LED3_TRIS = 0;
	LED4_TRIS = 0;
	LED5_TRIS = 0;
	LED6_TRIS = 0;
	LED7_TRIS = 0;
	LED_PUT(0x00);

    //configure Rx/Tx
    TRISCbits.RC7=1;
    TRISCbits.RC6=0;




	// Enable 4x/5x/96MHz PLL on PIC18F87J10, PIC18F97J60, PIC18F87J50, etc.
    OSCTUNE = 0x40;


	// PICDEM.net 2 board has POT on AN2, Temp Sensor on AN3
	
		ADCON0 = 0x01;		// ADON, Channel 0
		ADCON1 = 0x0E;		// Vdd/Vss is +/-REF, AN0 is analog

	ADCON2 = 0xBE;		// Right justify, 20TAD ACQ time, Fosc/64 (~21.0kHz)


    // Enable internal PORTB pull-ups
    INTCON2bits.RBPU = 0;

	// Configure USART
    TXSTA = 0x20;
    RCSTA = 0x90;


	// Use the low baud rate setting
		SPBRG = (GetPeripheralClock()+8*BAUD_RATE)/BAUD_RATE/16 - 1;



	// Enable Interrupts
	RCONbits.IPEN = 1;		// Enable interrupt priorities
    INTCONbits.GIEH = 1;
    INTCONbits.GIEL = 1;


}


void initUsart() {
        OpenUSART(  USART_TX_INT_OFF &
                    USART_RX_INT_OFF &
                    USART_ASYNCH_MODE &
                    USART_EIGHT_BIT &
                    USART_SYNC_SLAVE &
                    USART_CONT_RX &
                    USART_BRGH_LOW,129);//default 129
       // while(BusyUSART());	// for some reason one has to send a dummie to the USART
	   //   putcUSART('D'); // 'D' dummie
	      

}








